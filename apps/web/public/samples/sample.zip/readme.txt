This entry lives inside sample.zip and is read through the container codec.
